dojo.provide("dojango._base");

dojo.mixin(dojango, {
	// This where we can mixin functions that are directly accessbile via dojango.*
});